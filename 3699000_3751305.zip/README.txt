student id: s3699000, s3751305
Name: Tran Tien An, Do Minh Huy

Contribution: Tran Tien An 50%
	      Do Minh Huy 50%

To execute the file, please copy the Live.csv file and the Assignment2.ipynb in a same folder and then open the anaconda -> Jupyter notebook 

Please try to restart and run all cells in the Kenel taskbar 